repeat task.wait(2) until game:IsLoaded()
loadstring(game:HttpGet("https://raw.githubusercontent.com/NopNopA/NopNopA/main/noading.lua"))()